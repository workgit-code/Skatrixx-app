# Skatrixx-Prototype

Created by: Noah van Schijndel.

## Introduction
This is a clickable prototype for the Skatrixx Project @ USPC.


**WARNING:** This project might not be finished yet. It could contain catastrophic bugs or errors.

## Installation
Download / link git repository and locate to folder which allows a local server environment.

## Contribution
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
